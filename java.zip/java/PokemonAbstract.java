

public abstract class PokemonAbstract implements PokemonInterface {

    @Override
    public Pokemon criaPokemon(String nome, String tipo, int saude) {
        return new Pokemon(nome, tipo, saude);
    }

    @Override
    public void atacaPokemon(Pokemon pokemon) {
        pokemon.setSaude(pokemon.getSaude() - 10);
    }
}
