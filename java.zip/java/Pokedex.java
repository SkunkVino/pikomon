public class Pokedex extends PokemonAbstract{

    public String pokemonInfo(Pokemon pokemon){
        return "Nome do Pokemon : " +pokemon.getNome()+ ", tipo : " +pokemon.getTipo()+ ", Saude : "+pokemon.getSaude();
    }
}
