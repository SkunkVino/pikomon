public interface PokemonInterface {
    public Pokemon criaPokemon(String nome, String tipo, int saude);

    public void atacaPokemon(Pokemon pokemon);  

    public String pokemonInfo(Pokemon pokemon);
}

